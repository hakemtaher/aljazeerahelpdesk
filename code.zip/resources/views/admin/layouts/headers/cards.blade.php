<!-- Header -->
    <div class="header pb-7">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center pt-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 d-inline-block mb-0">{{$title}}</h6>
            </div>

            @stack('header-buttons')

            
          </div>
        </div>
      </div>
    </div>



<!-- <div class="container-fluid pt-3 pb-6">
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    New user created sucessfully
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
    </button>
  </div>
</div> -->