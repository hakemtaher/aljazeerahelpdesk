<footer class="py-5">
    <div class="container">
        @include('admin.layouts.footers.nav')
    </div>
</footer>