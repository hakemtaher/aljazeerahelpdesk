
{!! 

    $emailBody

!!}
