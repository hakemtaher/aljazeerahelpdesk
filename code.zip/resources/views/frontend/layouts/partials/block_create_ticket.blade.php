
<div class="section section-block-action text-center pb-0">
  <div class="container">
    <h4>{{ __('frontend.block_ticket_title') }}</h4>
    <p class="py-2">{{ __('frontend.block_ticket_subtitle') }}</p>
    <a href="{{ route('customer.ticket_new') }}" class="btn btn-primary btn-round">{{ __('frontend.submit_ticket') }}</a>
  </div>
</div>