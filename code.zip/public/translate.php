<?php

// $en = require "../resources/lang/en/auth.php";

// echo implode( '<br>', $en );

