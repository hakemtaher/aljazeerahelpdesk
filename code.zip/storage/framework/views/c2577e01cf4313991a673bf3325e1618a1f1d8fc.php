

<?php $__env->startSection('content'); ?>

<style>
    /*div.dataTables_wrapper div.dataTables_filter{
        text-align: left;
    }

    div.dataTables_length{
        text-align: right;
    }*/
</style>

    <?php echo $__env->make('admin.layouts.headers.cards', ['title' => __('labels.api_settings')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-3">
                <?php echo $__env->make('admin.settings.partials.sidebar', ['settingSidebarActive' => 'api'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0"> <?php echo e(__('labels.google_recaptcha')); ?></h3>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('settings.api.store')); ?>" id="my-form" autocomplete="off" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>

                            <div class="pl-lg-4">

                                <div class="form-group<?php echo e($errors->has('RECAPTCH_TYPE') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-RECAPTCH_TYPE"><?php echo e(__('labels.enable_disable_recaptcha')); ?></label><br>

                                    <label class="custom-toggle">
                                        <input type="checkbox" <?php echo e(old('RECAPTCH_TYPE', setting('RECAPTCH_TYPE'))=='GOOGLE'?'checked':''); ?> name="RECAPTCH_TYPE" value="GOOGLE">
                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                      </label>                                    

                                    <?php if($errors->has('RECAPTCH_TYPE')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('RECAPTCH_TYPE')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('GOOGLE_RECAPTCHA_KEY') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-GOOGLE_RECAPTCHA_KEY"><?php echo e(__('labels.recaptcha_site_key')); ?></label>
                                    <input type="text" name="GOOGLE_RECAPTCHA_KEY" id="input-GOOGLE_RECAPTCHA_KEY" class="form-control <?php echo e($errors->has('GOOGLE_RECAPTCHA_KEY') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('labels.recaptcha_site_key')); ?>" value="<?php echo e(old('GOOGLE_RECAPTCHA_KEY', setting('GOOGLE_RECAPTCHA_KEY'))); ?>" >

                                    <?php if($errors->has('GOOGLE_RECAPTCHA_KEY')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('GOOGLE_RECAPTCHA_KEY')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('GOOGLE_RECAPTCHA_SECRET') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-GOOGLE_RECAPTCHA_SECRET"><?php echo e(__('labels.recaptcha_secret_key')); ?></label>
                                    <input type="text" name="GOOGLE_RECAPTCHA_SECRET" id="input-GOOGLE_RECAPTCHA_SECRET" class="form-control <?php echo e($errors->has('GOOGLE_RECAPTCHA_SECRET') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('labels.recaptcha_secret_key')); ?>" value="<?php echo e(old('GOOGLE_RECAPTCHA_SECRET', setting('GOOGLE_RECAPTCHA_SECRET'))); ?>" >

                                    <?php if($errors->has('GOOGLE_RECAPTCHA_SECRET')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('GOOGLE_RECAPTCHA_SECRET')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="text-left">
                                    <button type="submit" class="btn btn-info mt-4"><?php echo e(__('labels.update')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>

        <?php echo $__env->make('admin.layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    </div>
<?php $__env->stopSection(); ?>


        <?php $__env->startPush('js'); ?>

        <script src="<?php echo e(asset('admin')); ?>/vendor/dropzone/dist/min/dropzone.min.js"></script>

        <script>
            $(document).ready(() => {
                $('#basic-datatable').DataTable();
            });
            $('#upload_image').on('change', (e) => {
                preview_image(e);
            });
        </script>
        <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', [ 'current_page' => 'api_settings' ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/admin/settings/api.blade.php ENDPATH**/ ?>