

<?php $__env->startSection('content'); ?>

<div class="container mt-5">

<div class="row">
  <div class="col">

      <div class="card shadow bg-white mt-4">

            <!-- Card header -->
            <div class="card-header bg-white border-0">
              <div class="row">
                <div class="col-12 col-md-6 mt-2">
                  <h4 class="mb-0">#<?php echo e($ticket->id); ?> <?php echo e($ticket->title); ?> </h4>
                  <?php echo front_status_label($ticket->status); ?>

                  <label for="" class="badge badge-pill badge-outline"  title="<?php echo e($ticket->created_at); ?>"><?php echo e($ticket->created_at->diffForHumans()); ?></label>
                </div>
                <div class="col-12 col-md-6 mt-2 text-right">

                  <?php if($ticket->status=='open' && setting('CUSTOMER_CLOSE_TICKET')=='yes'): ?>
                    <a href="<?php echo e(route('customer.ticket_update_status', [$ticket->id, 'closed'])); ?>" class="btn btn-primary  btn-icon">
                      <i data-feather="check" width="15"></i>
                      <?php echo e(__('frontend.close_ticket')); ?>

                    </a>
                  <?php endif; ?>
                  <?php if($ticket->status=='closed' && setting('USER_REOPEN_ISSUE')=='yes'): ?>
                    <a href="<?php echo e(route('customer.ticket_update_status', [$ticket->id, 'reopen'])); ?>" class="btn btn-danger btn-icon">
                      <i data-feather="refresh-ccw" width="15"></i> <?php echo e(__('frontend.reopen_ticket')); ?>

                    </a>
                  <?php endif; ?>

                    <a href="<?php echo e(route('customer.tickets')); ?>" class="btn btn-secondary btn-icon">
                      <i class="ni ni-support-16"></i>
                      <?php echo e(__('frontend.all_tickets')); ?>

                    </a>
                </div>
              </div>
              
            </div>
            <div class="card-body">

              <div class="ticket-view-replies">

                <div class="row">
                  <div class="col">

                    <?php $__currentLoopData = $ticket->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="ticket-view-reply mt-4">

                      <?php if(!empty($reply->user_id)): ?>

                        <div class="media align-items-center">
                          <span class="avatar avatar-sm rounded-circle">
                            <img alt="Image placeholder" src="<?php echo e(asset('uploads/user/'.$reply->user->image)); ?>">
                          </span>
                          <div class="media-body ml-2 d-none d-lg-block">
                            <span class="mb-0 text-sm font-weight-bold"> &nbsp; <?php echo e($reply->user->name); ?> </span>
                          </div>
                        </div>

                      <?php elseif(!empty($reply->customer_id)): ?>

                        <div class="media align-items-center">
                          <span class="avatar avatar-sm rounded-circle">
                            <img alt="Image placeholder" src="<?php echo e(asset('uploads/customer/'.$reply->customer->image)); ?>">
                          </span>
                          <div class="media-body  ml-2  d-none d-lg-block">
                            <span class="mb-0 text-sm font-weight-bold"> &nbsp; <?php echo e($reply->customer->name); ?> </span>
                          </div>
                        </div>

                      <?php endif; ?>

                      
                      <div class="ticket-description py-3 pl-3 mt-3 b-1 bg-white">
                        <div class="py-2"><?php echo e($reply->message); ?></div>
                        <hr class="my-3">
                        <ul class="list-unstyled list-inline">
                            <?php $__currentLoopData = $reply->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li class="py-2 d-block text-secondary btn-link"><a href="<?php echo e(url('uploads/reply_attachments/'.$file)); ?>" target="_blank" class="text-gray"> <i data-feather="download" width="15"></i> &nbsp;&nbsp; <?php echo e($file); ?></a></li>                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <small class="comment-date text-muted " title="<?php echo e($reply->created_at->format( setting('datetime_format'))); ?>">
                          <?php echo e($reply->created_at->diffForHumans()); ?>

                        </small>
                      </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                  </div>
                </div>
                
              </div>

            </div>

            <div class="card-footer bg-white py-4">
              <?php if($ticket->status!='closed'): ?>
                <?php echo $__env->make('customer-panel.tickets.partials.reply_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php else: ?>
                  <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo __('frontend.ticket_is_closed_message'); ?>

                      
                    </div>
              <?php endif; ?>

            </div>


      </div>

  </div>
</div>



</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

<script>
  
if ( document.getElementById('my-form') ) {
  $("#my-form").parsley({
     errorClass: 'is-invalid text-danger',
     // successClass: 'is-valid',
     errorsWrapper: '<span class="form-text text-danger"></span>',
     errorTemplate: '<span></span>',
     trigger: 'change',
     errorsContainer: function(el) {
          return el.$element.closest('.form-group');
      },
   });
}
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', ['body_class' => 'bg-default', 'nav_class' => 'navbar-theme'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/customer-panel/tickets/view.blade.php ENDPATH**/ ?>