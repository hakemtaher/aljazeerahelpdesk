

<?php $__env->startSection('content'); ?>

<style>
    /*div.dataTables_wrapper div.dataTables_filter{
        text-align: left;
    }

    div.dataTables_length{
        text-align: right;
    }*/
</style>

    <?php echo $__env->make('admin.layouts.headers.cards', ['title' => __('labels.language_settings') ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-3">
                <?php echo $__env->make('admin.settings.partials.sidebar', ['settingSidebarActive' => 'language'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col">
                <div class="card shadow">

                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('settings.language.store')); ?>" id="my-form" autocomplete="off" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>

                            <div class="pl-lg-4">

                                <div class="form-group<?php echo e($errors->has('default_lang') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-default_lang"><?php echo e(__('labels.default_language')); ?></label>
                                    <select name="default_lang" id="input-default_lang" class="form-control" required>
                                        <?php $__currentLoopData = getLanguages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($lang); ?>" <?php echo e(old('default_lang', setting('default_lang'))==$lang ? 'selected' :''); ?>><?php echo e($lang); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('default_lang')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('default_lang')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group text-left">
                                    <button type="submit" class="btn btn-info"><?php echo e(__('labels.update')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-12 col-md-8">
                                <h3 class="mb-0"><?php echo e(__('labels.available_languages')); ?></h3>
                            </div>
                            <div class="col-12 col-md-4 text-right">
                                
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php echo alert_html('You can manage translations and languages. Check <strong>Documentation</strong> for more info.', 'default'); ?>

                    </div>                    
                    
                    <table class="table align-items-center table-flush table-striped align-items-center w-100">
                        <thead>
                            <tr>
                                <th>Language</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = getLanguages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($lang); ?></td>
                                    <td width="10"></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

        <?php echo $__env->make('admin.layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    </div>
<?php $__env->stopSection(); ?>


        <?php $__env->startPush('js'); ?>

        <script src="<?php echo e(asset('admin')); ?>/vendor/dropzone/dist/min/dropzone.min.js"></script>

        <script>
            $(document).ready(() => {
                $('#basic-datatable').DataTable();
            });
            $('#upload_image').on('change', (e) => {
                preview_image(e);
            });
        </script>
        <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', [ 'current_page' => 'language_settings' ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/admin/settings/language.blade.php ENDPATH**/ ?>