
<?php echo $emailBody; ?>

<?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/admin/emails/template.blade.php ENDPATH**/ ?>