<div class="row align-items-center justify-content-xl-between text-center">
    <div class="col-lg-6">
        <div class="copyright text-left text-xl-left text-muted">
            &copy; <?php echo e(now()->year); ?> <a href="<?php echo e(url('/admin')); ?>" class="font-weight-bold ml-1"><?php echo e(setting('site_title')); ?></a> 
        </div>
    </div>
    <div class="col-lg-6">
        <div class="copyright text-right text-xl-right text-muted">
           v<?php echo e(setting('ultimatedesk_version')); ?> 
        </div>
    </div>
</div><?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/admin/layouts/footers/nav.blade.php ENDPATH**/ ?>