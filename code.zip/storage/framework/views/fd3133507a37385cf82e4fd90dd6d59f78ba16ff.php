<div class="modal fade" id="modal-assign-user-ticket-form" tabindex="-1" role="dialog" aria-labelledby="modal-assign-user-ticket-form" aria-hidden="true">
    <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-body p-0">
            	
                <div class="card bg-secondary border-0 mb-0">

                    <div class="card-body px-lg-5 py-lg-5">
                        <div class="text-center text-muted mb-4">
                            <small><?php echo e(__('labels.select_agent_info')); ?></small>
                        </div>
                        <form role="form" action="<?php echo e(route('tickets.assign_user')); ?>" method="post">
                            <?php echo csrf_field(); ?>


                            <input type="hidden" name="ticket_ids" id="assign_user_ticket_ids" value="<?php echo e(isset($ticket_id) ? $ticket_id : ''); ?>" />
                            <div class="form-group mb-3">
                                <select name="user" id="input-user" class="form-control" data-toggle="select">
                                    <option value="0"><?php echo e(__('labels.select')); ?></option>
                                    
                                    <?php $__currentLoopData = \App\User::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>" <?php echo e(isset($user_id) && $user_id==$user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            <div class="text-center">
                                <button type="reset" class="btn btn-secondary my-4" data-dismiss="modal"><?php echo e(__('labels.cancel')); ?></button>
                                <button type="submit" class="btn btn-primary my-4"><?php echo e(__('labels.assign_user')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>



                
            </div>
            
        </div>
    </div>
</div><?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/admin/ticket/modal_assign_user.blade.php ENDPATH**/ ?>