<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="<?php echo e(session('dir', 'ltr')); ?>">
    <head>
        <?php echo $__env->make('frontend.layouts.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
    <?php if(session('dir') == 'rtl'): ?>
    <link href="<?php echo e(asset('frontend/css/rtl.css')); ?>" rel="stylesheet">
<?php endif; ?>
    </head>

  <body class="page bg-theme">


    <?php echo $__env->make('frontend.layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  

    <div class="wrapper">

      <main class="page-content">
        <?php echo $__env->make('frontend.layouts.partials.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="footer footer-light mt-8 py-4">
      <?php echo $__env->make('frontend.layouts.footers.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>

  </div>

    <?php echo $__env->make('frontend.layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    <?php echo $__env->yieldPushContent('js'); ?>
    
</body>

</html>
<?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>