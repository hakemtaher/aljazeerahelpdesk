

<?php $__env->startSection('content'); ?>

<style>
    /*div.dataTables_wrapper div.dataTables_filter{
        text-align: left;
    }

    div.dataTables_length{
        text-align: right;
    }*/
</style>

    <?php echo $__env->make('admin.layouts.headers.cards', ['title' => __('labels.ticket_settings')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-3">
                <?php echo $__env->make('admin.settings.partials.sidebar', ['settingSidebarActive' => 'ticket'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0"><?php echo e(__('labels.ticket_settings')); ?></h3>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('settings.ticket.store')); ?>" id="my-form" autocomplete="off" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>

                            <div class="pl-lg-4">

                                <div class="form-group<?php echo e($errors->has('auto_assign_user') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-auto_assign_user"><?php echo e(__('labels.auto_assign_user')); ?></label><br>

                                    <label class="custom-toggle">
                                        <input type="checkbox" <?php echo e(old('auto_assign_user', setting('auto_assign_user'))=='yes'?'checked':''); ?> name="auto_assign_user" value="yes">
                                        <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('labels.no')); ?>" data-label-on="<?php echo e(__('labels.yes')); ?>"></span>
                                    </label>                                    

                                    <?php if($errors->has('auto_assign_user')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('auto_assign_user')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('ticket_default_assigned_user_id') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-ticket_default_assigned_user_id"><?php echo e(__('labels.default_assigned_user')); ?></label>
                                    <select name="ticket_default_assigned_user_id" id="input-user" class="form-control" data-toggle="select">
                                        <?php $__currentLoopData = \App\User::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>" <?php echo e(old('ticket_default_assigned_user_id', setting('ticket_default_assigned_user_id'))==$user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>

                                    <?php if($errors->has('ticket_default_assigned_user_id')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('ticket_default_assigned_user_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('USER_REOPEN_ISSUE') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-USER_REOPEN_ISSUE"><?php echo e(__('labels.alow_ticket_reopen')); ?></label><br>

                                    <label class="custom-toggle">
                                        <input type="checkbox" <?php echo e(old('USER_REOPEN_ISSUE', setting('USER_REOPEN_ISSUE'))=='yes'?'checked':''); ?> name="USER_REOPEN_ISSUE" value="yes">
                                        <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('labels.no')); ?>" data-label-on="<?php echo e(__('labels.yes')); ?>"></span>
                                      </label>                                    

                                    <?php if($errors->has('USER_REOPEN_ISSUE')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('USER_REOPEN_ISSUE')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('CUSTOMER_CLOSE_TICKET') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-CUSTOMER_CLOSE_TICKET"><?php echo e(__('labels.alow_ticket_close')); ?></label><br>

                                    <label class="custom-toggle">
                                        <input type="checkbox" <?php echo e(old('CUSTOMER_CLOSE_TICKET', setting('CUSTOMER_CLOSE_TICKET'))=='yes'?'checked':''); ?> name="CUSTOMER_CLOSE_TICKET" value="yes">
                                        <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('labels.no')); ?>" data-label-on="<?php echo e(__('labels.yes')); ?>"></span>
                                      </label>                                    

                                    <?php if($errors->has('CUSTOMER_CLOSE_TICKET')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('CUSTOMER_CLOSE_TICKET')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="text-left">
                                    <button type="submit" class="btn btn-info mt-4"><?php echo e(__('labels.update')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>

        <?php echo $__env->make('admin.layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    </div>
<?php $__env->stopSection(); ?>


        <?php $__env->startPush('js'); ?>

        <script src="<?php echo e(asset('admin')); ?>/vendor/dropzone/dist/min/dropzone.min.js"></script>

        <script>
            $(document).ready(() => {
                $('#basic-datatable').DataTable();
            });
            $('#upload_image').on('change', (e) => {
                preview_image(e);
            });
        </script>
        <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', [ 'current_page' => 'ticket_settings' ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/admin/settings/ticket.blade.php ENDPATH**/ ?>