<div class="list-group">
  
  <a href="<?php echo e(route('settings.general')); ?>" class="list-group-item list-group-item-action <?php echo e($settingSidebarActive=='general' ? 'active' : ''); ?>">
    <?php echo e(__('labels.general_settings')); ?>

  </a>
  
  <a href="<?php echo e(route('settings.language')); ?>" class="list-group-item list-group-item-action <?php echo e($settingSidebarActive=='language' ? 'active' : ''); ?>"><?php echo e(__('labels.language_settings')); ?></a>

  <a href="<?php echo e(route('settings.api')); ?>" class="list-group-item list-group-item-action <?php echo e($settingSidebarActive=='api' ? 'active' : ''); ?>"><?php echo e(__('labels.api_settings')); ?></a>

  <a href="<?php echo e(route('settings.frontend')); ?>" class="list-group-item list-group-item-action <?php echo e($settingSidebarActive=='frontend' ? 'active' : ''); ?>"><?php echo e(__('labels.frontend_settings')); ?></a>

  <a href="<?php echo e(route('settings.ticket')); ?>" class="list-group-item list-group-item-action <?php echo e($settingSidebarActive=='ticket' ? 'active' : ''); ?>"><?php echo e(__('labels.ticket_settings')); ?></a>

  <a href="<?php echo e(route('settings.email')); ?>" class="list-group-item list-group-item-action <?php echo e($settingSidebarActive=='email' ? 'active' : ''); ?>"><?php echo e(__('labels.email_settings')); ?></a>

  <a href="<?php echo e(route('settings.email_templates')); ?>" class="list-group-item list-group-item-action <?php echo e($settingSidebarActive=='email_templates' ? 'active' : ''); ?>"><?php echo e(__('labels.email_templates')); ?></a>
</div><?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/admin/settings/partials/sidebar.blade.php ENDPATH**/ ?>