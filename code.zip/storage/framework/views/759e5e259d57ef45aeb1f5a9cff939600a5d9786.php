          

          

<?php if($message = Session::get('success')): ?>

  <div class="container mt-5"><?php echo alert_html( $message, 'success' ); ?></div>

<?php endif; ?>


<?php if($message = Session::get('danger')): ?>

  <div class="container mt-5"><?php echo alert_html( $message, 'danger' ); ?></div>


<?php endif; ?>


<?php if($message = Session::get('warning')): ?>

  <div class="container mt-5"><?php echo alert_html( $message, 'warning' ); ?></div>

<?php endif; ?>


<?php if($message = Session::get('info')): ?>

  <div class="container mt-5"><?php echo alert_html( $message, 'info' ); ?></div>

<?php endif; ?><?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/frontend/layouts/partials/notification.blade.php ENDPATH**/ ?>