<form method="post" action="<?php echo e(route('customer.ticket_reply', $ticket->id)); ?>" id="my-form" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('post'); ?>
      <div class="form-group">
        <label class="require form-control-label"><?php echo e(__('labels.message')); ?></label>
        <textarea name="reply_description" rows="5"  required minlength="5" class="form-control"><?php echo e(old('reply_description')); ?></textarea>
        <?php if($errors->has('reply_description')): ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('reply_description')); ?></strong>
            </span>
        <?php endif; ?>
    </div>

    <div class="form-group file-group">
        <label class="require form-control-label"><?php echo e(__('labels.attachment')); ?></label>
        <input type="file" class="form-control" multiple="" name="reply_attachments[]">
        <?php if($errors->has('customer')): ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('customer')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
      <div class="form-group">
        <button type="submit" class="btn btn-primary btn-icon">
        <?php echo e(__('labels.submit')); ?> &nbsp; <i data-feather="send" width="15" stroke-width="2"></i>
        </button>
      </div>
</form><?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/customer-panel/tickets/partials/reply_form.blade.php ENDPATH**/ ?>