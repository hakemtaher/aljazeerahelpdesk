<div class="card shadow">
    <div class="card-header border-0">
        <div class="row align-items-center">
            <div class="col-8">
                <h3 class="mb-0"><?php echo e(__('labels.new_department')); ?></h3>
            </div>
        </div>
    </div>

    <div class="card-body">
        <form method="post" action="<?php echo e(route('departments.store')); ?>" id="my-form" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="pl-lg-4">
                <!-- English Name Input -->
                <div class="form-group<?php echo e($errors->has('name_en') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-name-en"><?php echo e(__('labels.name')); ?> (English)</label>
                    <input type="text" name="name_en" id="input-name-en" class="form-control <?php echo e($errors->has('name_en') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name in English')); ?>" value="<?php echo e(old('name_en')); ?>" required autofocus>

                    <?php if($errors->has('name_en')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name_en')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <!-- Arabic Name Input -->
                <div class="form-group<?php echo e($errors->has('name_ar') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-name-ar"><?php echo e(__('labels.name')); ?> (العربية)</label>
                    <input type="text" name="name_ar" id="input-name-ar" class="form-control <?php echo e($errors->has('name_ar') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name in Arabic')); ?>" value="<?php echo e(old('name_ar')); ?>" required>

                    <?php if($errors->has('name_ar')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name_ar')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('user') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-user"><?php echo e(__('labels.default_assigned_user')); ?></label>
                    <select name="assigned_user_id" id="input-user" class="form-control" data-toggle="select">
                        <option value="">Select User</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(old('assigned_user_id')==$user->id ? 'selected' :''); ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('assigned_user_id')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('assigned_user_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <span class="help-text text-muted" style="font-size: .8rem; font-style: italic;"><?php echo e(__('labels.future_tickets_message')); ?></span>
                </div>

                <div class="text-left">
                    <button type="submit" class="btn btn-info mt-4"><?php echo e(__('labels.submit')); ?></button>
                </div>
            </div>

        </form>
    </div>

</div><?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/admin/department/partials/add_new_form.blade.php ENDPATH**/ ?>