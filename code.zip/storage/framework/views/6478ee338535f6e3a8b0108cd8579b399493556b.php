<footer class="footer">
    <?php echo $__env->make('admin.layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer><?php /**PATH D:\Users\hakem\Downloads\ultimatedesk-v1.2\ultimatedesk-v1.2\code\resources\views/admin/layouts/footers/auth.blade.php ENDPATH**/ ?>